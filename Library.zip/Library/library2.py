from tkinter import *
import tkinter as tk
from tkinter import ttk
import mysql.connector
from tkinter import messagebox
import datetime
import pymysql
from tkcalendar import Calendar

class Library:

    def __init__(self,root):
        self.root=root
        self.root.title("Library Management System")
        self.root.geometry("1358x750+0+0")
        self.root.configure(bg='blue')

        MType= StringVar()
        Member= StringVar()
        Title= StringVar()
        Firstname=StringVar()
        Surname=StringVar()
        BookTitle= StringVar()
        BookType= StringVar()
        DateDue= StringVar()
        BookISBN=StringVar()
        Author=StringVar()
        Latefine=StringVar()
        MobileNo=StringVar()
        DateBorrowed=StringVar()
        ActualPrice=StringVar()
        Address=StringVar()
 #########################################################################################################################
        MainFrame=Frame(self.root,bg='blue')
        MainFrame.grid()


        TitleFrame = Frame(MainFrame,bd=10,width=1350,padx=60,relief=RIDGE)
        TitleFrame.pack(side=TOP)

        self.lblTitle =Label(TitleFrame ,width=37,font=('arial',40,'bold'),text="Library Management System")
        self.lblTitle.grid()

        ButtonFrame = Frame(MainFrame, bd=8,bg='VioletRed2', width=1350, height=50, relief=RIDGE)
        ButtonFrame.pack(side=BOTTOM)

        DataFrame = Frame(MainFrame, bd=10, width=1300, bg='violetred2',height=400, relief=RIDGE)
        DataFrame.pack(side=BOTTOM)

        DataFrameLeftCover = LabelFrame(DataFrame, bd=10, width=800,height=300,relief=RIDGE,bg='dark orange',font=('arial',12,'bold'),text="Library Membership Info:",)
        DataFrameLeftCover.pack(side=LEFT,padx=10)

        DataFrameLeft=Frame(DataFrameLeftCover,bd=10,width=800,height=300,padx=13,pady=2,relief=RIDGE)
        DataFrameLeft.pack(side=TOP)

        DataFrameLeftTb=LabelFrame(DataFrameLeftCover,bd=10,width=800,height=100,pady=4,padx=10,relief=RIDGE, font=('arial',12,'bold'),text="Library Member info:",)
        DataFrameLeftTb.pack(side=TOP)

        DataFrameRight=LabelFrame(DataFrame,bd=10,width=450,height=300,padx=10,relief=RIDGE, bg='violetred2',font=('arial',12,'bold') ,text="Book Details:", )
        DataFrameRight.pack(side=RIGHT)
        #########################################################################################################################
        def iExit():
            iExit = tk.messagebox.askquestion("Library Management System","Confirm if you want to exit")
            if iExit == 'yes':
                root.destroy()
                return

        def iReset():
            MType.set("")
            Member.set("")
            Title.set("")
            Firstname.set("")
            Surname.set("")
            BookTitle.set("")
            BookType.set("")
            DateDue.set("")
            BookISBN.set("")
            Author.set("")
            Latefine.set("")
            MobileNo.set("")
            DateBorrowed.set("")
            ActualPrice.set("")
            Address.set("")

        def addData ():
            if   Member.get() =="" or Firstname.get() ==""or Surname.get() =="":
                tk.messagebox.showerror("Library Management System", "Enter Correct Member details")
            else:
                sqlCon= pymysql.connect(host="Localhost",user="root",password="101995",database="library1")
                cur=sqlCon.cursor()
                cur.execute("insert into library values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",(

                Member.get(),
                Firstname.get(),
                Surname.get(),
                Address.get(),
                DateBorrowed.get(),

                DateDue.get(),

                Author.get(),
                BookISBN.get(),
                BookTitle.get(),
                )
                    )
                sqlCon.commit()
                DisplayData()
                sqlCon.close
                DateDue.set(cal.get_date())
                tk.messagebox.showinfo("Library Management System", "Record Entered successfully")

        def DisplayData():
            sqlCon = pymysql.connect(host="Localhost", user="root", password="101995", database="library1")
            cur = sqlCon.cursor()
            cur.execute("select * from library")
            result = cur.fetchall()
            if len(result) != 0:
                self.Library_records.delete(*self.Library_records.get_children())
                for row in result:
                    self.Library_records.insert('', END, values=row)
                    sqlCon.commit()

                    sqlCon.close
        def DeletDB():
            sqlCon = pymysql.connect(host="Localhost", user="root", password="101995", database="library1")
            cur = sqlCon.cursor()
            cur.execute("delete from Library where member=%s",Member.get())
            sqlCon.commit()
            DisplayData()
            sqlCon.close
            tk.messagebox.showinfo("Library Management System", "Record successfully deleted")

        def SearchDB():
            try:
                sqlCon = pymysql.connect(host="Localhost", user="root", password="101995", database="library1")
                cur = sqlCon.cursor()
                cur.execute("select from Library where member=%s", Member.get())
                row=cur.fetchone()
                Member.set(row=[0])
                Firstname.set(row=[1])
                Surname.set(row=[2])
                Address.set(row=[3])
                DateBorrowed.set(row=[4])

                DateDue.set(row=[5])

                Author.set(row=[6])
                BookISBN.set(row=[7])
                BookTitle.set(row=[8])
                sqlCon.commit()
            except:
                    tk.messagebox.showinfo("Library Management System", "no such record found")
                    sqlCon.close()

        def SelectBook(evt):
            values = str(booklist.get(booklist.curselection()))
            w = values
            if (w == "cinderella"):
                BookISBN.set("ISBN 89891")
                BookTitle.set("God is King")
                Author.set("paul parker")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.678")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)
            elif (w == "Game Design"):
                    BookISBN.set("ISBN 89892")
                    BookTitle.set("Design")
                    Author.set("Harry poris")
                    Latefine.set("Rs.50")
                    ActualPrice.set("Rs.578")
                    d1 = datetime.date.today()
                    d2 = datetime.timedelta(days=15)
                    d3 = (d1 + d2)
                    DateBorrowed.set(d1)
                    DateDue.set(d3)
            elif (w == "London"):
                BookISBN.set("ISBN 89893")
                BookTitle.set("Fallen London")
                Author.set("Megnan heoris")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.698")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)
            elif (w == "VHDL"):
                BookISBN.set("ISBN 86878")
                BookTitle.set("logic Design")
                Author.set("J K bhaskar")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.878")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)
            elif (w == "Anceint Rome"):
                BookISBN.set("ISBN 85894")
                BookTitle.set("Rome")
                Author.set("Foris luceint")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.1078")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "Head First Book"):
                BookISBN.set("ISBN 84895")
                BookTitle.set("Head First Book")
                Author.set("Harmur luceint")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.1178")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "python programming"):
                BookISBN.set("ISBN 39194")
                BookTitle.set("python programming")
                Author.set("Akash pallav")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.178")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "machine learning"):
                BookISBN.set("ISBN 83894")
                BookTitle.set("machine learning")
                Author.set("Flora Fernandies")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.448")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "digital signal"):
                BookISBN.set("ISBN 82894")
                BookTitle.set("Digital signal")
                Author.set("J K Bansal")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.1078")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "8051 microcontroller"):
                BookISBN.set("ISBN 29894")
                BookTitle.set("8051 microcontroller")
                Author.set("J K Bhaskar")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.918")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "java learning"):
                BookISBN.set("ISBN 19894")
                BookTitle.set("java learning")
                Author.set("suresh pandit")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.572")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "Pearl"):
                BookISBN.set("ISBN 89494")
                BookTitle.set("Pearl")
                Author.set("Himesh Jasra")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.978")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "History"):
                BookISBN.set("ISBN 89494")
                BookTitle.set("History")
                Author.set("A K Sahani")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.438")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "geography"):
                BookISBN.set("ISBN 13894")
                BookTitle.set("geography")
                Author.set("Uma Khureshi")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.578")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "political science"):
                BookISBN.set("ISBN 11694")
                BookTitle.set("Digital signal")
                Author.set("Ravi Shastri")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.378")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "Snow white"):
                BookISBN.set("ISBN 29894")
                BookTitle.set("Snow white")
                Author.set("Herbert Lewit")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.178")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)

            elif (w == "Hello India"):
                BookISBN.set("ISBN 89894")
                BookTitle.set("Hello India")
                Author.set("Bhushan Pal")
                Latefine.set("Rs.50")
                ActualPrice.set("Rs.1021")
                d1 = datetime.date.today()
                d2 = datetime.timedelta(days=15)
                d3 = (d1 + d2)
                DateBorrowed.set(d1)
                DateDue.set(d3)



        def LibraryInfo(ev):
            Member.set(row=[0])
            Firstname.set(row=[1])
            Surname.set(row=[2])
            Address.set(row=[3])
            DateBorrowed.set(row=[4])

            DateDue.set(row=[5])

            Author.set(row=[6])
            BookISBN.set(row=[7])
            BookTitle.set(row=[8])


        ###############################################################################################################################
        self.lblMemberType = Label( DataFrameLeft , font=('arial', 12, 'bold'), text="Member Type",padx=2,pady=2)
        self.lblMemberType.grid(row=0,column=0,sticky=W)

        self.cboMemberType=ttk.Combobox(DataFrameLeft,textvariable=MType,state='readonly',font=('arial',12,'bold'),width=34)
        self.cboMemberType['value']=('','Student','Lecturer','Admin staff')
        self.cboMemberType.current(0)
        self.cboMemberType.grid(row=0,column=1)

        self.lblBookISBN = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Book ID", padx=2, pady=2)
        self.lblBookISBN.grid(row=0, column=2, sticky=W)
        self.lblBookISBN = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=BookISBN, width=31)
        self.lblBookISBN.grid(row=0, column=3)

        self.lblMemberRef = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Member Refe No", padx=2, pady=2)
        self.lblMemberRef.grid(row=1, column=0, sticky=W)
        self.lblMemberRef = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=Member, width=36)
        self.lblMemberRef.grid(row=1, column=1)

        self.lblBookTitle = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Book Title", padx=2, pady=2)
        self.lblBookTitle.grid(row=1, column=2, sticky=W)
        self.lblBookTitle = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=BookTitle, width=31)
        self.lblBookTitle.grid(row=1, column=3)

        self.lblTitle = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Title:", padx=2, pady=2)
        self.lblTitle.grid(row=2, column=0, sticky=W)

        self.cboTitle = ttk.Combobox(DataFrameLeft, textvariable=Title, state='readonly',
                                          font=('arial', 12, 'bold'), width=34)
        self.cboTitle['value'] = ('', 'Mr.', 'Mrs', 'Miss','Dr','Capt.','Ms.')
        self.cboTitle.current(0)
        self.cboTitle.grid(row=2, column=1)

        self.lblFirstname = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="First Name", padx=2, pady=2)
        self.lblFirstname.grid(row=3, column=0, sticky=W)
        self.lblFirstname = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=Firstname, width=36)
        self.lblFirstname.grid(row=3, column=1)

        self.lblAuthor = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Author:", padx=2, pady=2)
        self.lblAuthor.grid(row=2, column=2, sticky=W)
        self.lblAuthor = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=Author, width=31)
        self.lblAuthor.grid(row=2, column=3)

        self.lblDateDue = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Date Due", padx=2, pady=2)
        self.lblDateDue.grid(row=3, column=2, sticky=W)
        self.lblDateDue = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=DateDue, width=31)
        self.lblDateDue.grid(row=3, column=3)

        self.lblSurname = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Surname", padx=2, pady=2)
        self.lblSurname.grid(row=4, column=0, sticky=W)
        self.lblSurname = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=Surname, width=36)
        self.lblSurname.grid(row=4, column=1)

        self.lblLateReturnFine = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Late Return Fine", padx=2, pady=2)
        self.lblLateReturnFine.grid(row=6, column=2, sticky=W)
        self.lblLateReturnFine = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=Latefine, width=31)
        self.lblLateReturnFine.grid(row=6, column=3)

        self.lblMobileNo = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Mobile No", padx=2, pady=2)
        self.lblMobileNo.grid(row=5, column=0, sticky=W)
        self.lblMobileNo = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=MobileNo, width=36)
        self.lblMobileNo.grid(row=5, column=1)

        self.lblDateBorrowed = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Date Borrowed", padx=2, pady=2)
        self.lblDateBorrowed.grid(row=4, column=2, sticky=W)
        self.lblDateBorrowed = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=DateBorrowed, width=31)
        self.lblDateBorrowed.grid(row=4, column=3)

        self.lblActualPrice = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Actual Price", padx=2, pady=2)
        self.lblActualPrice.grid(row=5, column=2, sticky=W)
        self.lblActualPrice = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=ActualPrice, width=31)
        self.lblActualPrice.grid(row=5, column=3)

        self.lblAddress = Label(DataFrameLeft, font=('arial', 12, 'bold'), text="Address", padx=2, pady=2)
        self.lblAddress.grid(row=6, column=0, sticky=W)
        self.lblAddress = Entry(DataFrameLeft, font=('arial', 12, 'bold'), textvariable=Address, width=36)
        self.lblAddress.grid(row=6, column=1)





        ########################################################CALENDER#################################################################
        cal=Calendar(DataFrameRight,selectmode="day",year=2021,month=2,day=12,date_pattern='yyyy-mm-dd',font=('arial',10,'bold'),padx=10)
        cal.grid(row=0,column=0,pady=10)






        ######################################################LISTBOX###################################################################
        scrollbar=Scrollbar(DataFrameRight,orient=VERTICAL)
        scrollbar.grid(row=1,column=1,sticky='ns')

        ListofBooks=['cinderella','Game Design','Anceint Rome','VHDL','London','Snow white','Hello India',
                     'Head First Book','python programming','machine learning','digital signal','8051 microcontroller','java learning',
            'Pearl','History ','geography','political science','Mechanical engineering', ]



        booklist=Listbox(DataFrameRight,width=20,height=12,font=('arial',12,'bold'),bg='cyan',yscrollcommand=scrollbar.set)
        booklist.bind('<<ListboxSelect>>',SelectBook)
        booklist.grid(row=1,column=0,padx=3)
        scrollbar.config(command=booklist.yview)

        for  items in ListofBooks:
             booklist.insert(END,items)
##########################################################TREE VIEW FRAME DETAIL#####################################################################

        scroll_x=Scrollbar(DataFrameLeftTb,orient=HORIZONTAL)
        scroll_y=Scrollbar(DataFrameLeftTb,orient=VERTICAL)

        self.Library_records=ttk.Treeview(DataFrameLeftTb,height=5,column=("member","firstname","surname","address","dateborrowed","bookisbn","duedate","author","booktitle"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        self.Library_records.heading("member",text="Member")
        self.Library_records.heading("firstname", text="Firstname")
        self.Library_records.heading("surname", text="Surname")
        self.Library_records.heading("address", text="Address")
        self.Library_records.heading("dateborrowed", text="Date Borrowed")
        self.Library_records.heading("bookisbn", text="Date Due")
        self.Library_records.heading("duedate", text="Author")
        self.Library_records.heading("author", text="BookISBN")
        self.Library_records.heading("booktitle", text="Book Title")



        self.Library_records['show']='headings'

        self.Library_records.column("member", width=70)
        self.Library_records.column("firstname", width=100)
        self.Library_records.column("surname", width=100)
        self.Library_records.column("address", width=100)
        self.Library_records.column("dateborrowed", width=70)
        self.Library_records.column("bookisbn", width=70)
        self.Library_records.column("duedate", width=100)
        self.Library_records.column("author", width=70)
        self.Library_records.column("booktitle", width=70)

        self.Library_records.pack(fill=BOTH,expand=1)
        self.Library_records.bind("<ButtonRelease-1>", LibraryInfo)
        DisplayData()


        #########################################################################################################################
        self.btnDisplayData=Button(ButtonFrame,text="Display data",font=('arial',19,'bold'),padx=4,width=16,bd=4,bg='dark orange',command=addData)
        self.btnDisplayData.grid(row=0,column=0,padx=3)

        self.btnDelete = Button(ButtonFrame, text="Delete", font=('arial', 19, 'bold'), padx=4, width=16,
                                     bd=4, bg='dark orange',command=DeletDB)
        self.btnDelete.grid(row=0, column=1, padx=3)

        self.btnReset = Button(ButtonFrame, text="Reset", font=('arial', 19, 'bold'), padx=4, width=16,
                                     bd=4, bg='dark orange',command= iReset)
        self.btnReset.grid(row=0, column=2, padx=3)

        self.btnSearch = Button(ButtonFrame, text="Search", font=('arial', 19, 'bold'), padx=4, width=16,
                                     bd=4, bg='dark orange',command=SearchDB)
        self.btnSearch.grid(row=0, column=3, padx=3)

        self.btnExit = Button(ButtonFrame, text="Exit", font=('arial', 19, 'bold'), padx=4, width=16,
                                     bd=4, bg='dark orange',command=iExit)
        self.btnExit.grid(row=0, column=4, padx=3)


#########################################################################################################################



if __name__ == "__main__":
    root = Tk()
    application = Library(root)
    if __name__ == '__main__':
        root.mainloop()

